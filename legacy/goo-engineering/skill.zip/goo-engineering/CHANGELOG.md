# Changelog

## 0.1.0 - 2026-10-09
Initial coordinator, selective platform references, evidence/approval rules, curated upstream catalog, project templates, local-only helper and test scenarios. Not yet validated end to end inside coding hosts or real Android/Windows production projects.
