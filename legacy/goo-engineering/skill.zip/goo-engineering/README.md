# Goo Engineering

**Version 0.1.0 - starter implementation, researched 2026-10-09.**

A portable coordinator skill for evidence-based development across web, Android, Windows, Telegram bots and backend services. It stages discovery, competitor research, architecture/data/API planning, distinctive UI, performance budgets, implementation, verification and release. Existing codebases start with a read-only audit and a KEEP/REMOVE/ADD/FIX/REDESIGN decision.

The aim is appropriate, maintainable software with measurable quality, not a promise of perfect code, zero vulnerabilities, automatic market leadership or unlimited scale.

## Contents
- `SKILL.md`: compact orchestration and approval rules.
- `references/`: selectively loaded discipline/platform playbooks and source catalog.
- `assets/`: templates, reviewed tool catalog, unresolved tooling-lock example.
- `scripts/engineering.py`: bounded heuristic discovery, local install, non-overwriting plan scaffolding and structural plan checks.
- `tests/`: executable helper tests and separate, not-yet-run model evaluation scenarios.
- `README.ar.md`: Arabic guide.
- `VALIDATION.md`: what was and was not tested.

## Quick start
Requires Python 3.10+ only for the helpers. From this folder, preview then explicitly apply a project-local installation:
```sh
python scripts/engineering.py install /path/to/project --agent codex
python scripts/engineering.py install /path/to/project --agent codex --apply
```
Use `claude` or `cursor` for their conventional project locations. The install copies **this skill only**, not the catalog's external tools. The destination must not already exist. Review source and host documentation before use; host-level integration is not certified by local file-copy tests.

Ask the coding agent to use `goo-engineering`, inspect its available capabilities, choose the relevant profiles and begin discovery. Existing repositories stay read-only until permission to run scripts or write artifacts is granted.

## Local helper usage
```sh
python scripts/engineering.py detect /path/to/project
python scripts/engineering.py scaffold /path/to/project --mode new --profiles web,backend
python scripts/engineering.py scaffold /path/to/project --mode new --profiles web,backend --apply
python scripts/engineering.py check-plan /path/to/project
python -m unittest discover -s tests -v
```
Scaffolding produces DRAFT planning artifacts and will not pass `check-plan` until blockers, decisions, artifacts and an approval reference are filled. That check verifies structure, not the truth of approval or the quality of architecture. Configure actual application tests/scans/builds in repository-native CI after selecting its stack.

## Composition
Choose one specification/workflow provider. Keep an existing sound provider; consider OpenSpec or Spec Kit, not both by default. Add semantic navigation, frontend design and verification tools only for a demonstrated need and supported environment. Review exact versions, licenses, hooks, network disclosure and permissions before any install.

The catalog is not a dependency lock or security endorsement. Third-party components and fonts are not bundled. Source links and review date live in `references/tool-catalog.md` and `assets/tool-registry.json`.

## Safety and limitations
The bundle cannot enforce a model's obedience or replace branch protection, a sandbox, CI, human review or specialist audits. It does not grant permissions, run an entire project automatically, publish a GitHub repository, install third-party tools or execute platform tests without their environment. Read `VALIDATION.md` before relying on it.

## Publish or extend
The folder can become a GitHub repository after owner/license/security review. Tag tested releases and publish `skill.zip` plus a checksum. Add platform adapters and held-out scenario tests rather than inflating the core prompt. See the maintenance reference.

## License
Original bundle material is MIT licensed; linked third-party projects retain their own licenses. No third-party skill text/code has been vendored.
