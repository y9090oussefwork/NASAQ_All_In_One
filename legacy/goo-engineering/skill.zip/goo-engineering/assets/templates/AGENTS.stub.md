# Project engineering instructions

Use the `goo-engineering` skill when available. Start with `docs/engineering/INDEX.md`, `.engineering/project.json`, and the relevant feature/module documentation.

Read the affected source and tests before changes. Preserve scoped instructions and existing architecture. Do not overwrite user work, install tools, delete data, change security policy, publish or deploy without the applicable approval. Run the actual repository-native verification commands and report evidence; never report unavailable checks as passed.

Keep the canonical specifications, relevant maps and handoff current in the same review as code changes. This file is a starter; add confirmed commands and repository-specific rules without duplicating the complete skill.
