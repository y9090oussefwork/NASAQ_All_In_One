# Existing project assessment

Status: DRAFT

## Read-only inventory and source anchors

{{Complete with verified evidence, an approved decision, or a justified N/A.}}

## Discoverable features and confidence

{{Complete with verified evidence, an approved decision, or a justified N/A.}}

## Strengths and verified defects

{{Complete with verified evidence, an approved decision, or a justified N/A.}}

## Candidate debt and unavailable evidence

{{Complete with verified evidence, an approved decision, or a justified N/A.}}

## KEEP / REMOVE / ADD / FIX / REDESIGN proposals

{{Complete with verified evidence, an approved decision, or a justified N/A.}}
