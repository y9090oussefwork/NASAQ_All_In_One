# Data model and contracts

Status: DRAFT

## Entities, ownership, keys and invariants

{{Complete with verified evidence, an approved decision, or a justified N/A.}}

## Queries, indexes, transactions and concurrency

{{Complete with verified evidence, an approved decision, or a justified N/A.}}

## Versioned API shapes and authorization

{{Complete with verified evidence, an approved decision, or a justified N/A.}}

## Network calls per journey, caches and retries

{{Complete with verified evidence, an approved decision, or a justified N/A.}}

## Migration, restore, load and contract verification

{{Complete with verified evidence, an approved decision, or a justified N/A.}}
