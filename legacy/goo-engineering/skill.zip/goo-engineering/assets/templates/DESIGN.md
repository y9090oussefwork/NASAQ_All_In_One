# Product design system

Status: DRAFT

## Audience, journeys and visual alternatives

{{Complete with verified evidence, an approved decision, or a justified N/A.}}

## Approved representative screens with real content

{{Complete with verified evidence, an approved decision, or a justified N/A.}}

## Semantic colors, typography, spacing and components

{{Complete with verified evidence, an approved decision, or a justified N/A.}}

## RTL, keyboard, screen reader, large text and state coverage

{{Complete with verified evidence, an approved decision, or a justified N/A.}}

## Visual review evidence and resource budget

{{Complete with verified evidence, an approved decision, or a justified N/A.}}
