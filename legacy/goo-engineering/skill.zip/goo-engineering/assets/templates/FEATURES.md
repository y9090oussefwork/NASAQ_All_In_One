# Feature registry

Status: DRAFT

## Stable feature IDs and status

{{Complete with verified evidence, an approved decision, or a justified N/A.}}

## Links to canonical specifications

{{Complete with verified evidence, an approved decision, or a justified N/A.}}

## Source/module/contract/test traceability

{{Complete with verified evidence, an approved decision, or a justified N/A.}}

## Dependencies, ownership and verification evidence

{{Complete with verified evidence, an approved decision, or a justified N/A.}}
