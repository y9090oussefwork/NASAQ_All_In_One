# Current project handoff

Status: DRAFT

## Current revision and phase

{{Complete with verified evidence, an approved decision, or a justified N/A.}}

## Decisions and approved scope

{{Complete with verified evidence, an approved decision, or a justified N/A.}}

## Completed versus unverified work

{{Complete with verified evidence, an approved decision, or a justified N/A.}}

## Blocking questions and next relevant files

{{Complete with verified evidence, an approved decision, or a justified N/A.}}

## Executed command evidence or explicit NOT RUN

{{Complete with verified evidence, an approved decision, or a justified N/A.}}
