# Performance and resource budgets

Status: DRAFT

## Reference devices, build and network

{{Complete with verified evidence, an approved decision, or a justified N/A.}}

## Active workload, data sizes and traffic mix

{{Complete with verified evidence, an approved decision, or a justified N/A.}}

## Latency, CPU, memory, I/O and bytes per journey

{{Complete with verified evidence, an approved decision, or a justified N/A.}}

## Test scenarios, stop limits and capacity headroom

{{Complete with verified evidence, an approved decision, or a justified N/A.}}

## Proposed targets versus measured baseline/results

{{Complete with verified evidence, an approved decision, or a justified N/A.}}
