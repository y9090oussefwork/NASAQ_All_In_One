# Template usage

Templates are intentionally incomplete. Replace placeholders with evidence and decisions. Preserve existing repository docs and link their canonical specs instead of duplicating them. The helper creates only selected planning artifacts and never overwrites existing files.

A document becomes `Status: READY` only after its contents have been completed and reviewed for the plan. That marker is not proof that software has been implemented or tested. Keep actual execution evidence separate. The project JSON needs an authentic approval reference; the helper cannot authenticate a human approval.

`toolchain-lock.example.json` is an unresolved shape example, not an installable lock. Resolve exact versions and approvals before use. `quality-gates.example.json` describes CI configuration requirements; no fictitious universal runner is supplied. Prefer project-native CI commands.
