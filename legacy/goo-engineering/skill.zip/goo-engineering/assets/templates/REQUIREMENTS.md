# Product requirements

Status: DRAFT

## Problem, users and measurable success

{{Complete with verified evidence, an approved decision, or a justified N/A.}}

## Platforms, languages, accessibility and supported hardware

{{Complete with verified evidence, an approved decision, or a justified N/A.}}

## Feature priorities, non-goals and release scope

{{Complete with verified evidence, an approved decision, or a justified N/A.}}

## Acceptance criteria and business invariants

{{Complete with verified evidence, an approved decision, or a justified N/A.}}

## Budget, constraints, assumptions and approvals

{{Complete with verified evidence, an approved decision, or a justified N/A.}}
