# Security plan

Status: DRAFT

## Assets, actors and trust boundaries

{{Complete with verified evidence, an approved decision, or a justified N/A.}}

## Data/tenant ownership and authorization matrix

{{Complete with verified evidence, an approved decision, or a justified N/A.}}

## Applicable versioned verification controls

{{Complete with verified evidence, an approved decision, or a justified N/A.}}

## Secret/dependency/tool supply-chain controls

{{Complete with verified evidence, an approved decision, or a justified N/A.}}

## Risks, review plan and authorized test targets

{{Complete with verified evidence, an approved decision, or a justified N/A.}}
