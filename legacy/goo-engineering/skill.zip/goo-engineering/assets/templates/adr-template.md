# ADR-___: Decision title

Status: PROPOSED

## Context
{{Constraints and evidence.}}
## Options
{{Viable alternatives and weighted tradeoffs.}}
## Decision
{{Choice, owner and approval reference.}}
## Consequences
{{Cost, risks, performance, security and reversibility.}}
## Revisit conditions
{{Evidence that would justify superseding this decision.}}
