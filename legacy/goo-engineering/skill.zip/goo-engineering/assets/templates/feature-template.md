# FEAT-___: Feature name

Status: DRAFT

## User value and actors
{{Describe the purpose and who is authorized.}}
## Acceptance criteria
{{Use observable outcomes, including failure and boundary behavior.}}
## Scope and invariants
{{Define non-goals, data ownership and properties that must always hold.}}
## UI and contracts
{{Link canonical design, API/schema, offline and error states.}}
## Impact and source anchors
{{List modules, symbols, dependencies and migrations.}}
## Verification
{{Map every critical acceptance criterion to tests and required environment.}}
## Evidence and approval
{{Record source revision, executed results, remaining risks and approval reference.}}
