# Architecture, database, and API decisions

## Stack selection
Compare 2-3 viable options against weighted product needs: platform integration, operational simplicity, resource envelope, team maintainability, ecosystem support, accessibility, deployment/update mechanism, security, total cost, and licensing. Verify current supported versions and compatibility in primary documentation. Respect an existing healthy stack. Do not switch frameworks merely for novelty or because an agent prefers one.

Propose the simplest architecture that satisfies measured requirements. Consider a modular monolith before distributed services; justify additional queues, caches, services, containers, or orchestration separately. Keep domain boundaries explicit and enforceable. A desktop tool may need no server; an offline app may need only a local database. Do not introduce a backend, database, account system, or AI feature without a real need.

## Data model checklist
Start from access patterns and invariants. Define entities, ownership/tenancy, identifiers, keys, uniqueness, nullability, relationships, deletion rules, timezone handling, monetary precision, retention and privacy. Choose normalization or deliberate denormalization with a stated consistency plan.

Design transactions, isolation, concurrent writes, idempotency, duplicate submissions, uniqueness races, and retry behavior. Do not rely only on application checks for a database invariant that needs a constraint. Decide soft versus hard deletion; record restore and audit consequences.

Choose indexes from actual query shapes and data volumes, not one index on every column. Inspect representative query plans; test pagination, selectivity, lock duration, connection pool size and N+1 behavior. PostgreSQL EXPLAIN ANALYZE executes statements; never run a write analysis casually against production. Prefer isolated realistic fixtures.

Use versioned migrations, compatibility across app versions, expand/migrate/contract when necessary, backup/restore drills, and rollback or roll-forward plans. Test upgrades from a previous release, not only a fresh database. Document migration locks, duration, disk overhead and failure recovery.

## Contracts and network
Specify request/response shapes, validation, authn/authz, tenant/object/property checks, errors, versioning, idempotency keys, timeouts, retry policy, pagination, payload limits, caching/privacy, and observability. Use OpenAPI for appropriate HTTP APIs; choose other contract formats when the protocol calls for them.

Map every important screen/action to the calls it makes and the server work it triggers. Eliminate duplicate calls, use cancellation and request coalescing where correct, bound concurrency, and prefer delta sync/conditional requests when useful. Do not retry non-idempotent actions blindly. Bound retries and use backoff/jitter to avoid synchronized retry storms.

For asynchronous jobs, define durable handoff, acknowledgment timing, deduplication, queue limits, backpressure, dead-letter handling, retry caps, job ordering, and operator recovery. Do not equate "message received" with "work durably completed".

## Sources
- https://www.postgresql.org/docs/current/using-explain.html
- https://core.telegram.org/bots/api
