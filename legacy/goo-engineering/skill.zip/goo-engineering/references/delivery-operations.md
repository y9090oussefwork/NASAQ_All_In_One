# Delivery, maintenance and recovery

## Change hygiene
Use scoped branches and small reviewable diffs. Do not edit unrelated files or generated output directly when a generator owns it. Respect local uncommitted work. Use worktrees for genuinely independent changes; serialize shared schema/contracts/lockfile changes. Keep one integrator responsible for cross-module compatibility.

Configure native formatter/linter/type or compiler checks, relevant tests, dependency and secret checks, and build validation. Add architectural dependency rules and unused-code/duplicate detection when supported. Knip and dependency-cruiser are JS/TS choices, not universal language analyzers. A candidate unused file may be reached dynamically, by reflection, plugin discovery, configuration, or downstream public consumers; investigate before deletion.

## CI tiers
Fast review checks on each change; broader integration/security suites on merge or a suitable cadence; device, soak, capacity, restore and release checks on relevant milestones. Do not make every trivial commit run every expensive test. Cache build inputs correctly without leaking secrets or accepting stale results. Use reproducible dependency locks and pinned CI action revisions with least-privilege tokens.

Required checks and protected branches should be enforced in repository settings controlled by the owner. The agent must not silently weaken checks, increase tolerances, update snapshots or approve its own exception. Each exception needs rationale, owner, expiry and compensating evidence.

## Release
Build a reproducible artifact; track version and provenance. Validate configuration, migrations, install/upgrade/uninstall, code signing and update mechanism as applicable. Do not ask the agent to hold production signing keys. Use staged rollout/feature flags when useful; define rollback triggers and compatibility with old clients.

Establish health/readiness, structured redacted logs, metrics, traces where useful, error tracking, dashboards, actionable alerts and retention. OpenTelemetry can instrument signals; it is not an entire monitoring backend by itself. Set telemetry/cardinality/cost budgets. Verify backups by restoring them and testing the restored application. Record recovery point/time targets and the actual drill result.

## Maintenance
Assign dependency upgrades, support/deprecation policy, incident response, runbooks, vulnerability triage and technical-debt owners. Audit feature flags, unused packages, abandoned endpoints and retention over time. Product success also needs usability/user-feedback validation; a green test suite alone does not prove market fit.

## Sources
- https://github.com/webpro-nl/knip
- https://github.com/sverweij/dependency-cruiser
- https://github.com/kucherenko/jscpd
- https://opentelemetry.io/docs/
