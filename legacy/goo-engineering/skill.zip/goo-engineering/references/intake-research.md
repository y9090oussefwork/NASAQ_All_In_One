# Intake and research

## Interview in rounds
1. Product: problem, intended users, platforms, examples, core value, desired first release, exclusions.
2. Features: actors, user journeys, roles, permissions, data ownership, acceptance criteria, edge cases, priority.
3. Constraints: budget, timeline, team skills, supported hardware/OS/browser versions, accessibility, languages/RTL, offline needs, hosting regions, privacy, integrations.
4. Workload: active rather than registered users, traffic mix, peak events, requests/session, data/media sizes, retention/growth, acceptable latency, availability and recovery needs.
5. Design: personality, references, brand assets and usage rights, preferred/avoided styles, dense productivity UI versus expressive marketing UI, dark/light requirements.
6. Decision packet: propose missing requirements and tradeoffs, highlight cost and risk, collect approval or bounded delegation.

Ask 3-5 relevant questions at a time. Do not demand a number the user cannot know: propose explicitly labeled low/base/high scenarios, then validate them. Do not block progress on noncritical preferences; record a reversible assumption. Monetary, legal, privacy, and critical security decisions need appropriate authorization or specialist input.

## Existing-project report
For each claim show a file/symbol/route/test reference or identify it as inference. Cover inventory, feature status, strengths, confirmed defects, candidate debt, architecture, database, UI, security, performance, test gaps, and operational readiness. Provide KEEP/REMOVE/ADD/FIX/REDESIGN choices with benefit, regression risk, effort range, and confidence. Do not call an unexecuted test a baseline.

## Competitors and references
Use user-provided public links first. When permitted and useful, find a small relevant comparison set. Record URL, access date, product/version/tier, observed behavior, evidence, and uncertainty. Compare user journeys, feature coverage, usability, accessibility, offline behavior, public pricing, and public performance evidence. Distinguish a missing observed feature from a proven absence. Mark inaccessible functions unknown. A public landing page does not establish internal architecture, server capacity, or security.

Do not access private accounts, evade restrictions, run security/load scans, or copy assets without permission. Avoid claims of guaranteed commercial superiority. Convert research into opportunities and hypotheses with acceptance or usability tests. Avoid endless feature accumulation: prioritize a differentiated first release.
