# Installation and host integration

## Bundle versus tools
This bundle contains one coordinator skill, original references/templates, a curated upstream catalog and local Python helpers. It contains no third-party skill source, network installer, font binary, credential, SDK, browser or database. External tools are not installed automatically.

Use Python 3.10+ for local helpers. No pip packages are required. Review the local source before running it. The helpers do not execute repository code or make network requests. Run them in an isolated workspace when the repository is untrusted; path safeguards are defense in depth, not a hardened OS sandbox.

From an extracted or cloned `goo-engineering` folder:
```sh
python scripts/engineering.py install /absolute/path/to/project --agent codex
python scripts/engineering.py install /absolute/path/to/project --agent codex --apply
```
The first command previews. The second copies this skill only. Supported values: `codex`, `claude`, `cursor`. All installs are project-local. The helper refuses an existing destination or symlink/junction path and does not overwrite global host settings, root AGENTS.md or other skills. No automatic updater is included; review version diffs before replacing a prior installation.

Conventional discovery paths reviewed on 2026-10-09:
- Codex: `.agents/skills/goo-engineering/`
- Claude Code: `.claude/skills/goo-engineering/`
- Cursor: `.cursor/skills/goo-engineering/`

Host version and permissions still matter. Confirm discovery in the actual host. Use an explicit skill mention/command supported there. A plain chat without repository/terminal access cannot install SDKs or run native builds; it can work on planning and uploaded content only. A local skill install does not grant MCP, network or production permissions.

## GitHub publication
The extracted folder is repository-ready source. Before publishing: review the license, run local tests, inspect for secrets, create the repository under the desired owner, commit files, tag a release and publish the tested `skill.zip` with a checksum. Publishing and repository visibility require the owner's explicit choice; this package has not been uploaded to an account.

A future one-command GitHub installer must resolve a reviewed immutable revision, inspect install scripts and permissions, install into the chosen host's project scope and confirm discovery. Do not invent a repository URL or claim all coding agents share a single installer.

## Third-party composition
Preserve the chosen spec provider's native files. Record a tooling lock with source, immutable revision/integrity, permissions, license review and install evidence. Avoid overlapping global hooks. Activate a relevant specialist workflow by the host's supported invocation mechanism; nested skill calling is not universally supported. When unavailable, use the applicable local reference and report the fallback without pretending the external tool ran.

Sources:
- https://agentskills.io/specification
- https://developers.openai.com/codex/skills/
- https://code.claude.com/docs/en/skills
- https://cursor.com/docs/skills.md
