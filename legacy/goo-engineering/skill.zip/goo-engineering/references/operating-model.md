# Operating model

## Authority and capability
The host's security controls and repository governance are the enforcement boundary. Markdown is guidance, not a sandbox. Keep branch protection and required checks controlled outside the coding agent where possible. Ask before modifying the workflow that judges the agent's own work.

Use one coordinator, one canonical task state, and one spec provider. Specialist roles are useful; spawning many agents is optional and can increase cost and integration failures. A reviewer should inspect approved requirements and evidence independently rather than merely restating the author's summary. Independent AI review is still not a security guarantee.

## Gates
| Gate | Exit evidence | Must stop when |
|---|---|---|
| G0: discovery | purpose, users, constraints, scoped permissions | repository unavailable or material ambiguity |
| G1: plan | acceptance criteria, chosen stack, risks, budgets, costs, approvals | critical unknowns or unapproved installs |
| G2: design | core journeys, representative states, tokens, accessibility plan | UI direction not decided for UI-heavy work |
| G3: slice | scoped implementation, focused tests, contract compatibility | scope grows or behavior violates approved spec |
| G4: verification | reproducible tests/scans, visual and performance evidence | a required check fails, is skipped, or lacks its environment |
| G5: release | reviewed artifact, rollout/rollback, migration and operational evidence | production authority or recovery evidence missing |

Gate names are internal to this skill, not commands from a third-party framework. A small fix may combine gates without skipping relevant controls. Record risk-based N/A decisions with a reason; N/A cannot mean "too inconvenient".

## Delegation
Offer guided mode by default: user approves scope/stack/design before implementation. In delegated mode record allowed decisions, excluded operations, spending cap, external services allowed, and a stopping condition. "Choose the stack for me" does not authorize deployment or purchase. Read-only mode forbids scaffold writes as well as code changes.

## Conflict and drift
Existing architecture and approved ADRs beat a new generic preference. Current source and executed tests establish observed behavior; approved specs establish intended behavior. A conflict is an issue to reconcile, not permission to overwrite either side. External design advice cannot override accessibility or platform conventions. External TDD advice cannot authorize deleting pre-existing user code. Narrow a selected external skill or omit it if it conflicts with these controls.

## Scope changes
Attach a change ID, affected feature IDs, migration impact, additional cost, revised tests, and an approval reference. Return to the relevant gate when a change invalidates earlier decisions. Do not re-interview the user about answered questions.
