# Resource budgets and performance engineering

## Budget before optimization
Specify a user journey, reference hardware, OS/runtime build, network conditions, dataset scale, cache state, measurement method and acceptance threshold. Label an initial number as a proposed target, not an achieved result. Prefer user-facing latency and resource/cost measures over a generic "fast" goal.

Track applicable budgets: cold/warm startup, interaction latency, p50/p95/p99 API latency, throughput, error rate, CPU, steady/peak memory, disk I/O and growth, battery/idle wakeups, bytes per task/session, application download size, queue lag, connection pools, database queries per operation, and cost per useful operation. Do not apply web metrics to a native app or service metrics to a static website.

For web, current Core Web Vitals good thresholds are LCP <= 2.5 s, INP <= 200 ms, and CLS <= 0.1 at the 75th percentile of visits. Treat lab measurements as diagnostics; they do not establish actual field percentiles. Recheck the official definitions before adopting thresholds in a future project.

## Model load honestly
Registered accounts are not active users, active users are not simultaneous in-flight requests, and virtual users are not a universal capacity unit. Define arrival rates, think time, endpoint mix, read/write ratio, media sizes, background jobs, cache hit rate, burst factor, and ramp duration. Use representative data and authentication.

Illustrative arithmetic, not a sizing promise: 1,000 active users performing one request every five seconds imply approximately 200 requests/second before background work and bursts. At a steady mean response time of 0.2 seconds, approximately 40 requests are in flight on average under stable conditions. Real capacity still requires measurement and headroom.

## Optimize with evidence
Measure a baseline -> identify the bottleneck -> change one meaningful variable -> compare under the same conditions -> retain only a useful improvement. Distinguish CPU-bound from I/O-bound work. Use release/profile builds and realistic devices. Record environment noise and repeated-run variance.

Potential measures include payload minimization, pagination, conditional requests, compression when beneficial, image sizing, bounded caching with explicit invalidation and tenant isolation, request cancellation, bounded parallelism, efficient query plans, delayed noncritical initialization and background work scheduled around platform limits. Evaluate tradeoffs: caching can reduce requests while increasing memory/staleness risk; compression costs CPU; prefetch can waste data.

## Capacity and resilience suite
Use smoke -> expected load -> stress -> spike -> soak -> breakpoint tests as appropriate. Specify target ownership, rate limits, stop conditions, test duration, budget and recovery goals before execution. Observe server and database saturation as well as client latency. A load generator can be the bottleneck; report it.

Test timeouts, partial outages, pool/queue exhaustion, duplicate events, retries, degraded dependencies and recovery. Never attack a third-party service or production in the name of benchmarking. Mock Telegram/external vendors and load-test the application's owned handler/worker boundary.

## Sources
- https://web.dev/articles/vitals
- https://grafana.com/docs/k6/latest/testing-guides/test-types/
- https://developer.android.com/topic/performance/benchmarking/macrobenchmark-overview
- https://learn.microsoft.com/en-us/windows/apps/develop/performance/
