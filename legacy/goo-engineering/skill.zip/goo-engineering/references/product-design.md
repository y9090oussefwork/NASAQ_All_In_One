# Product design, not template decoration

## Start from the product
Understand audience, tasks, content density, identity, platform conventions and usability needs. Produce 2-3 genuinely distinct visual directions only when this is a substantial design decision. Explain typography, hierarchy, palette, layout, interaction and tradeoffs. A screenshot reference is inspiration, not permission to reproduce branding or assets.

For a native app, favor native conventions and accessibility. Do not ban a platform font simply to look less AI-generated. Do not force a web landing-page style onto a Windows productivity app or an Android settings screen. A plain Telegram bot needs clear conversational UX, not a web design package; add web design only for a Mini App or dashboard.

## Before widespread implementation
Approve representative screens with realistic content, including a primary task, a dense/data-heavy state, and important error/empty/loading states. Use a previewable implementation or actual design tool available in the environment. Clearly distinguish a proposed mockup from implemented UI. If visual tooling is unavailable, report the limitation and do not claim visual validation.

## Design system
Record semantic color tokens (surface/text/border/action/status), type scale, font pairing and fallback, Arabic glyph quality, licensing, line-height, spacing, density, layout breakpoints, radii, elevation, icon source, interaction states, focus indication, and motion/reduced-motion policy. Use colors for semantic meaning, not decoration alone. Use only required font weights/assets and test their loading and memory/network cost.

Cover keyboard and screen-reader navigation, readable contrast, touch targets, localization and RTL mirroring, large text/zoom, focus order, permission-denied states, offline states, pagination and long content. Test real Arabic/English mixtures, long names, dates, currencies and numbers. Preserve comprehension in light and dark themes if both are supported.

## Tool policy
Choose Impeccable for frontend critique/refinement where supported; choose UI UX Pro Max as a palette/type/style research aid, or Anthropic frontend-design as a lean alternative. Do not activate multiple incompatible aesthetic rulebooks. Curated aesthetic suggestions do not replace measured accessibility or user approval.

For web components, visual comparisons can use Playwright in a reproducible environment. A pixel-matching screenshot proves consistency, not attractiveness or usability. Review screenshots manually against approved intent and content. Never auto-accept changed snapshots to silence a failing visual test.

## Evidence and sources
Store the selected direction, alternatives rejected, representative screenshots, review notes and fixes. No font binaries are bundled with this skill.
- https://github.com/pbakaus/impeccable
- https://github.com/nextlevelbuilder/ui-ux-pro-max-skill
- https://github.com/anthropics/skills/tree/main/skills/frontend-design
- https://playwright.dev/docs/test-snapshots
