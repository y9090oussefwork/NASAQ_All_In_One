# Android profile

Compare native Kotlin/Compose with cross-platform options only when cross-platform delivery is a real need. Base the decision on native APIs, responsiveness, offline behavior, supported devices, long-term maintenance and measured prototypes, not a universal ranking.

Design lifecycle-aware state, process-death recovery, cancellation, background-work constraints, permissions, offline cache/synchronization and conflict resolution. Avoid main-thread I/O, uncontrolled retries, redundant network calls, excessive wakeups and unnecessary media downloads. Specify metered-network and low-battery behavior. Budget cold/warm startup, jank/frame timing, memory, binary size and bytes per journey.

Use platform unit and instrumentation/Compose tests for correctness, and Maestro for appropriate end-to-end journeys. Use release-like builds and Macrobenchmark for startup and rendering. Benchmark on representative physical hardware for defensible real-device claims; an emulator result is not a physical-device performance guarantee. Consider Baseline Profiles and measure benefit instead of quoting a universal speedup.

Test low-memory devices, rotation/resizing, activity recreation, process death, denied/revoked permissions, no network, flaky network, slow storage, background restrictions, large text, TalkBack and RTL. Apply the relevant mobile security requirements. Verify app upgrade, database migration and rollback implications, signing and store/platform policy before release using current official docs.

Sources:
- https://developer.android.com/topic/performance/benchmarking/macrobenchmark-overview
- https://developer.android.com/topic/performance/baselineprofiles/measure-baselineprofile
- https://mas.owasp.org/
- https://github.com/mobile-dev-inc/Maestro
