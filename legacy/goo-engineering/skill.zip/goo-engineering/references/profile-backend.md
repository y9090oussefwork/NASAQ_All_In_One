# Backend, API and worker profile

Load architecture-data-api, performance, security and delivery references. Decide whether a server is needed at all. Model requests and jobs, data growth, peak traffic, tenancy, external dependencies and per-operation costs.

Use explicit contracts and server-side validation/authorization. Plan resource limits, connection pools, transactions, concurrency, timeouts, retries, idempotency, pagination, payload limits, caches and invalidation, queues and recovery. Prioritize correctness and observability before speculative scale architecture.

Verify unit/business invariants, isolated integration tests, negative authorization tests and concurrent operations. Use Schemathesis for suitable OpenAPI/GraphQL interfaces; it supplements rather than replaces business acceptance criteria. Use k6 for owned load tests and correlate client metrics with server/database saturation. Use OpenTelemetry where it improves end-to-end diagnosis; budget signal volume and protect sensitive data.

Test migration from a prior release, backup restoration, degraded dependencies, worker restart and duplicate delivery. Decide and measure availability, recovery point/time, retention, latency and cost objectives. Avoid production credentials and customer datasets in generated tests.

Sources: https://schemathesis.readthedocs.io/en/stable/ ; https://grafana.com/docs/k6/latest/ ; https://opentelemetry.io/docs/
