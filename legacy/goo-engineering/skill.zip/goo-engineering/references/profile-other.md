# Additional and mixed platforms

This workflow is extensible, not a claim of prevalidated coverage for every language, game engine, embedded board, iOS platform or desktop framework.

When a project does not fit a bundled profile, record its platform, runtime, delivery mechanism, toolchain, resource constraints, native UI/security conventions, test environment and current primary documentation. Propose an adapter before installing unrelated web tooling. For mobile/desktop cross-platform frameworks, combine shared-code checks with every shipped platform's actual runtime/device checks.

A CLI needs command/exit-code/stdin/stdout/error and packaging tests rather than screenshot tests. A library needs public API compatibility, consumer examples and support policies. A real-time/embedded system may need timing, hardware-in-the-loop and specialist safety verification. An AI-enabled product additionally needs model/prompt versioning, evaluation datasets, error/abuse cases, privacy, latency/cost budgets and safe fallbacks.

Do not silently map "unknown" to a familiar stack. Mark unsupported test environments BLOCKED. Extend the local tool registry only after source, license, installation, permission and compatibility review. Document where the bundled checklist ends and specialized expertise is required.
