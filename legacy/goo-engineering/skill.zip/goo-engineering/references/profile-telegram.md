# Telegram bot profile

Choose the language/framework from maintenance and workload needs. Design commands, conversation state, cancellation/back navigation, error messages, localization, administrator authorization and abuse controls. A bot's UI is primarily its conversation. Add web UI tooling only for a real Mini App or management panel.

Choose webhook or long polling deliberately; they are alternative delivery modes. Consult current Bot API docs for authentication, update handling, limits and retry semantics. Validate webhook authenticity using supported mechanisms and protect the bot token. Plan deduplication keyed by update identity, concurrency/order per chat, idempotent effects, bounded queues and durable acknowledgment.

Do expensive work asynchronously after a safe durable handoff. Handle vendor rate limits and retry_after with bounded retries/backoff. Avoid busy polling, unnecessary media reuploads and unbounded broadcasts. Reuse cached media identifiers only where valid. Model resource needs for the bot's own handlers/workers and external API quotas separately.

Use sanitized recorded/synthetic update fixtures to test duplicates, malformed updates, permissions, conversation transitions, restart recovery, overload and retry storms. Load-test owned worker/API boundaries with Telegram calls mocked; never stress-test Telegram servers. Use a test bot for permitted functional smoke tests.

Sources:
- https://core.telegram.org/bots/faq
- https://core.telegram.org/bots/api
