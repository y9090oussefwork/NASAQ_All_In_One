# Web profile

Select rendering and framework based on actual SEO, interaction, offline, accessibility, hosting and team needs. A content site and an authenticated dashboard need not share an architecture. Use an existing healthy stack.

Plan routing, content/data ownership, semantic HTML, form validation, error boundaries, accessibility, responsive layout, locale/RTL and asset budgets. Minimize unused JavaScript, fonts and images; decide caching and invalidation, optimistic updates and rollback deliberately. Do not add a giant component library for one widget.

Verify user journeys with Playwright when suitable; review visual baselines in a consistent browser/OS/font environment. Pair automatic accessibility checks with keyboard/screen-reader and real-content inspection. Measure Core Web Vitals using field data when available, and use lab tooling to diagnose rather than to claim universal user performance.

For JS/TS select appropriate compiler/linter, Knip for unused candidates and dependency-cruiser for architectural constraints when worthwhile. Their output requires interpretation. Load the backend profile for server routes/APIs, and the security profile for auth, uploads and sensitive data.

Sources: https://playwright.dev/docs/test-snapshots ; https://web.dev/articles/vitals ; https://github.com/webpro-nl/knip
