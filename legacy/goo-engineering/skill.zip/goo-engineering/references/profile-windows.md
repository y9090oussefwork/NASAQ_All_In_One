# Windows desktop profile

Compare appropriate native/.NET options, a cross-platform native framework, or a webview-based shell only when each is viable. Do not assume every .NET service is a Windows desktop app. Investigate OS integration, accessibility, deployment/update needs and representative memory/startup measurements.

Plan UI-thread responsiveness, asynchronous I/O/cancellation, background work, bounded caches, large lists, high DPI, multiple monitors, large text, keyboard shortcuts, focus order, Narrator and RTL/localization. Specify whether admin rights, services, registry changes or shell integration are actually required.

Use the selected stack's unit/integration runner. FlaUI is an option for applications exposing suitable Windows UI Automation; it is not a universal browser or mobile tester. Run UI checks on a real suitable Windows environment with an interactive session when required. Profile startup, idle/peak memory, CPU, disk and rendering using Visual Studio diagnostics or WPR/WPA; use .NET tools for .NET workloads.

Test install, upgrade, rollback/recovery and uninstall; per-user versus per-machine deployment; missing runtime handling; signing; file/credential permissions; long paths and non-ASCII paths; interrupted updates and compatibility with existing data. Never claim Windows-native checks ran in a Linux-only environment.

Sources:
- https://learn.microsoft.com/en-us/windows/apps/develop/performance/
- https://learn.microsoft.com/en-us/windows/apps/develop/performance/profiling-tools
- https://github.com/FlaUI/FlaUI
