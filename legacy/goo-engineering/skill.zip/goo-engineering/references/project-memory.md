# Project memory, maps, and traceability

## Navigation, not a giant prompt
Keep a compact index linking to domain/module documentation. Each agent reads the index, current change, relevant module/spec, and tests. Retrieve symbols/references using native IDE/LSP tooling or Serena when supported and useful. Use a selective Repomix export only when needed; a full repository dump is neither permanent memory nor a safe default.

## Canonical artifacts
- Product brief and feature registry: stable ID, actor, purpose, status, priority, dependencies, spec, source anchors, tests, owner.
- Context/deployment map: people, clients, services, stores, external providers, trust boundaries, environments.
- Module/dependency map: responsibilities, allowed import directions, public contracts, ownership, generated code boundaries.
- Data map: entities, keys, relations, constraints, tenant boundaries, migration ownership.
- UI/navigation and sequence maps: critical journeys, network calls, background work, error and recovery paths.
- Decisions: ADRs containing context, considered alternatives, tradeoffs, decision, date and superseding references.
- Current change: scoped plan, tasks, unresolved blockers, decisions, evidence and handoff.

Choose a subset appropriate to complexity. Mermaid text in Git is a useful portable format; CodeBoarding output is an optional derived view. Do not store two editable copies of the same contract. Link an existing OpenSpec/Spec Kit source rather than duplicating its specification into another folder.

## Provenance
Record source revision or source-file hashes, analysis date, changed paths, coverage limitations, and confidence on derived maps. Prefer stable symbols and file paths; line numbers may move. Distinguish observed source facts, executed evidence, design intent, and assumptions. Record actual feature states such as planned, partial, implemented-unverified, verified, and deprecated.

## Update policy
A behavior change updates its acceptance criteria, contracts and feature entry in the same review. A dependency change refreshes affected graphs; a schema change refreshes ERD/migrations; a UI change refreshes reviewed visual references. CI can validate links, schema consistency and architecture rules, but semantic correctness still needs review.

Maintain a concise handoff: current revision, goal, completed work, pending tasks, tested commands/results, blockers, decisions, next files. Do not preserve endless transcripts or secret-bearing logs. Treat stale knowledge as an investigation aid rather than truth.
