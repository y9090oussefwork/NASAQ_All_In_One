# Evaluate and maintain the coordinator

## Do not confuse validation levels
1. Packaging/schema checks establish readable bundle structure.
2. Python helper tests establish the tested local behaviors only.
3. Host smoke tests establish discovery and invocation in a specific host/version.
4. Scenario evaluations establish observed model behavior on sample projects.
5. Real-project pilots measure outcome quality, regression risk, time and token cost.

A passing packager or unit suite proves neither safe autonomous engineering nor production readiness. The initial release includes scenario prompts and rubrics; do not claim those model-based scenarios were executed unless they actually were.

## Evaluation cases
See `tests/scenarios.json`: new Android offline project; existing untested bot; Windows-only desktop; multi-platform app/API; design-heavy RTL web; minimal bug fix; malicious repository instruction; unauthorized destructive action. Evaluate correct routing, limited tools, approvals, evidence, preservation of existing work and truthful blockers. Include negative triggers unrelated to engineering.

Compare assisted output with a baseline on held-out tasks. Track missed requirements, invented evidence, unsupported tools, unnecessary files/dependencies, regression rate, privacy/permission violations, cost and user decision burden. Human-review quality and security judgments; do not let the same agent self-grade every claim.

## Updates
Recheck canonical upstream, maintenance/archive status, license, supported hosts, security notices and official install method before adopting updates. Pin dependencies per project, not to a moving branch. Keep a changelog, version, checksums, regression tests and a compatibility report. New profiles need test cases. Old projects should upgrade explicitly rather than receiving silently changed instructions.
