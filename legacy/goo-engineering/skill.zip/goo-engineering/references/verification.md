# Risk-based verification

## Build tests from requirements, not implementation alone
For each feature ID define independent acceptance criteria and map them to test cases. Test business invariants, success, invalid input, boundary values, unauthorized roles/tenants, duplicates, concurrency, cancellation, offline behavior and recovery. Do not let generated tests simply restate the current implementation's bugs.

Layer tests appropriately: fast unit tests; integration tests with real storage/protocol behavior in isolated fixtures; contract tests; a small reliable set of end-to-end journeys; visual/accessibility checks; security, performance and recovery tests when relevant. Use Testcontainers where the environment supports containers, not as a compulsory dependency everywhere. Use property-based testing, schema-driven API tests or mutation testing when the risk and payoff justify them.

## Platform routing
- Web: platform unit runner + Playwright user journeys/visual checks + appropriate accessibility and network/performance instrumentation.
- Android: platform unit/instrumentation/Compose tests + Maestro for suitable E2E flows; Macrobenchmark for startup/rendering, not a substitute for correctness tests.
- Windows: native/.NET test runner; FlaUI for compatible Windows UI automation; native profilers for application resource use.
- Telegram: deterministic update fixtures, ordering, deduplication, rate-limit/retry paths, malformed/unauthorized updates, durable queues and safe test-bot smoke checks.
- API: integration and authorization matrix + OpenAPI/Schemathesis when appropriate; k6 for owned service load/capacity.

## Reliability
Control clocks, random seeds, test data and dependencies. Avoid real customer data. Bound waits, clean up fixtures, isolate test users/tenants, prevent network calls outside approved hosts, and document device/OS constraints. Quarantine flaky tests only with an owner and expiry; never silently remove them from required protection.

Coverage is a diagnostic, not proof of correctness. Use risk and changed-code coverage rather than demanding 100% across generated/framework code. Separate implementation from independent review of the test oracle. Snapshot updates need explicit review.

## Evidence record
Store revision, command, tool/runtime versions, target environment, dataset/workload, start time, exit code, findings, relevant sanitized logs and artifacts. Use PASS/FAIL/BLOCKED/SKIPPED/N/A consistently. N/A needs an applicability reason; skipped/blocked required tests prevent VERIFIED or RELEASE READY.

The supplied `check-plan` script validates planning structure only. Configure actual repository-native commands in CI after stack selection; this bundle does not pretend a generic command runs every platform's tests. Windows UI and physical Android performance tests require those environments.

## Sources
- https://playwright.dev/docs/test-snapshots
- https://github.com/mobile-dev-inc/Maestro
- https://github.com/FlaUI/FlaUI
- https://schemathesis.readthedocs.io/en/stable/
- https://github.com/testcontainers
