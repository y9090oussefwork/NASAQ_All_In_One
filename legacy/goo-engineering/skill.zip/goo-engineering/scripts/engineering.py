#!/usr/bin/env python3
"""Local-only helpers for Goo Engineering; Python 3.10+, standard library.

No network calls, subprocesses, repository script execution or dependency installs.
File-system safeguards are not a substitute for an OS sandbox against a hostile
concurrent process. Explicit --apply is required for writes; existing files stay.
"""
from __future__ import annotations

import argparse
import hashlib
import json
import os
import re
import stat
import sys
from collections import Counter
from pathlib import Path, PurePosixPath
from typing import Any

ROOT = Path(__file__).resolve().parents[1]
PROFILES = {"web", "android", "windows", "telegram", "backend", "other"}
HOST_PATHS = {"codex": ".agents/skills", "claude": ".claude/skills", "cursor": ".cursor/skills"}
SKIP = {".git", ".hg", ".svn", ".idea", ".vscode", ".agents", ".claude", ".cursor",
        ".engineering", ".serena", ".codeboarding", "node_modules", "vendor", ".venv",
        "venv", "__pycache__", ".gradle", "build", "dist", "target", "bin", "obj",
        ".next", ".nuxt", "coverage", ".cache", "Pods"}
SOURCE_SUFFIXES = {".py", ".js", ".jsx", ".ts", ".tsx", ".kt", ".kts", ".java", ".cs",
                   ".rs", ".go", ".cpp", ".c", ".h", ".swift", ".dart", ".php", ".rb"}
MAX_TEXT_BYTES = 1024 * 1024
BASE_DOCS = ["REQUIREMENTS.md", "FEATURES.md", "ARCHITECTURE.md", "DECISIONS.md",
             "PERFORMANCE.md", "SECURITY.md", "VERIFICATION.md", "OPERATIONS.md", "HANDOFF.md"]


def is_link(path: Path) -> bool:
    """Include Windows junctions when the Python runtime exposes that check."""
    if path.is_symlink():
        return True
    if hasattr(path, "is_junction") and path.is_junction():
        return True
    try:
        info = path.lstat()
    except FileNotFoundError:
        return False
    # Covers reparse points on older Windows Python versions too.
    return bool(getattr(info, "st_file_attributes", 0) & getattr(stat, "FILE_ATTRIBUTE_REPARSE_POINT", 0))


def clean_root(value: str | Path) -> Path:
    root = Path(os.path.abspath(os.path.expanduser(str(value))))
    for p in list(reversed(root.parents)) + [root]:
        if is_link(p):
            raise ValueError(f"Refusing symlink/junction path: {p}")
    if not root.is_dir():
        raise ValueError(f"Project directory does not exist: {root}")
    return root


def confined(root: Path, relative: str) -> Path:
    """Validate a portable relative path and reject existing link components."""
    rel = PurePosixPath(relative)
    if not relative or rel.is_absolute() or ".." in rel.parts or "\\" in relative or ":" in relative:
        raise ValueError(f"Unsafe relative path: {relative!r}")
    if rel.as_posix() in (".", ""):
        raise ValueError("Empty destination path")
    p = root
    for part in rel.parts:
        p = p / part
        if is_link(p):
            raise ValueError(f"Refusing symlink/junction: {p}")
    return p


def read_text(path: Path, limit: int = MAX_TEXT_BYTES) -> str:
    if is_link(path) or not path.is_file():
        raise ValueError(f"Not a regular non-link file: {path}")
    if path.stat().st_size > limit:
        raise ValueError(f"File exceeds safe read limit: {path}")
    with path.open("rb") as f:
        data = f.read(limit + 1)
    if len(data) > limit:
        raise ValueError(f"File grew beyond safe read limit: {path}")
    return data.decode("utf-8")


def read_json(path: Path) -> dict[str, Any]:
    result = json.loads(read_text(path))
    if not isinstance(result, dict):
        raise ValueError(f"Expected a JSON object: {path}")
    return result


def detect(project: str | Path, max_files: int = 20000) -> dict[str, Any]:
    root = clean_root(project)
    if max_files < 1 or max_files > 1000000:
        raise ValueError("max-files must be between 1 and 1000000")
    candidates: dict[str, list[str]] = {}
    manifests: list[str] = []
    warnings: list[str] = []
    suffixes: Counter[str] = Counter()
    count = 0
    truncated = False
    def add(profile: str, evidence: str) -> None:
        rows = candidates.setdefault(profile, [])
        if evidence not in rows and len(rows) < 12:
            rows.append(evidence)
    def walk_error(error: OSError) -> None:
        warnings.append(f"Unreadable directory: {error.filename}")
    for folder, dirs, files in os.walk(root, followlinks=False, onerror=walk_error):
        base = Path(folder)
        dirs[:] = sorted(d for d in dirs if d not in SKIP and not is_link(base / d))
        for name in sorted(files):
            path = base / name
            if is_link(path) or not path.is_file():
                continue
            if count >= max_files:
                truncated = True
                break
            count += 1
            rel = path.relative_to(root).as_posix()
            suffix = path.suffix.lower()
            if suffix in SOURCE_SUFFIXES:
                suffixes[suffix] += 1
            if name == "AndroidManifest.xml":
                add("android", rel)
            if name in {"pubspec.yaml", "Cargo.toml", "go.mod", "Package.swift"}:
                manifests.append(rel)
                add("other", rel + " (runtime manifest; delivery platform needs confirmation)")
            readable = name in {"package.json", "requirements.txt", "pyproject.toml", "build.gradle", "build.gradle.kts"} or suffix == ".csproj"
            if not readable:
                continue
            manifests.append(rel)
            try:
                text = read_text(path)
                low = text.lower()
                if name == "package.json":
                    data = json.loads(text)
                    if not isinstance(data, dict):
                        raise ValueError("package.json is not an object")
                    deps: set[str] = set()
                    for group in ("dependencies", "devDependencies", "peerDependencies"):
                        value = data.get(group, {})
                        if isinstance(value, dict):
                            deps.update(str(k).lower() for k in value)
                    if deps & {"next", "react-dom", "vue", "svelte", "astro", "@angular/core", "solid-js"}:
                        add("web", rel + " (web framework dependency)")
                    if "react-native" in deps:
                        add("android", rel + " (React Native; target confirmation required)")
                        add("other", rel + " (possible additional mobile targets)")
                    if deps & {"express", "fastify", "koa", "hono", "@nestjs/core"}:
                        add("backend", rel + " (server framework dependency)")
                    if deps & {"telegraf", "grammy", "node-telegram-bot-api"}:
                        add("telegram", rel + " (Telegram library dependency)")
                    if deps & {"electron", "@tauri-apps/api"}:
                        add("other", rel + " (desktop shell; OS targets need confirmation)")
                elif name in {"requirements.txt", "pyproject.toml"}:
                    if re.search(r"\b(aiogram|python-telegram-bot)\b", low):
                        add("telegram", rel + " (Telegram dependency text)")
                    if re.search(r"\b(fastapi|django|flask)\b", low):
                        add("backend", rel + " (server dependency text)")
                elif name.startswith("build.gradle") and "com.android." in low:
                    add("android", rel + " (Android Gradle plugin text)")
                elif suffix == ".csproj":
                    if any(marker in low for marker in ("<usewpf>true", "<usewindowsforms>true", "<usewinui>true")):
                        add("windows", rel + " (Windows UI project property)")
                    if "microsoft.net.sdk.web" in low:
                        add("backend", rel + " (ASP.NET SDK project)")
            except (OSError, UnicodeError, ValueError) as exc:
                warnings.append(f"Cannot safely parse {rel}: {type(exc).__name__}")
        if truncated:
            break
    return {"schema_version": 1, "method": "bounded-manifest-heuristics-not-semantic-audit",
            "files_inspected": count, "truncated": truncated,
            "mode_hint": "existing" if suffixes else "unknown",
            "profile_candidates": candidates, "profile_confirmation_required": True,
            "source_extension_counts": dict(sorted(suffixes.items())),
            "manifest_paths": sorted(manifests)[:200], "warnings": warnings[:100],
            "limitations": ["No repository code executed; no network used; no packages installed.",
                            "Dependencies can be unused or misleading; confirm actual architecture.",
                            "Configured build/vendor/cache paths and symlinks are excluded; maps are not complete."]}


def write_batch(root: Path, batch: dict[str, bytes], apply: bool) -> dict[str, Any]:
    paths: dict[str, Path] = {}
    for rel in batch:
        dest = confined(root, rel)
        if dest.exists():
            raise ValueError(f"Refusing to overwrite existing path: {dest}")
        for parent in dest.parents:
            if parent == root:
                break
            if parent.exists() and not parent.is_dir():
                raise ValueError(f"Destination parent is not a directory: {parent}")
        paths[rel] = dest
    if apply:
        for rel, dest in paths.items():
            confined(root, rel)  # Repeat link check immediately before writing.
            dest.parent.mkdir(parents=True, exist_ok=True)
            with dest.open("xb") as handle:
                handle.write(batch[rel])
    return {"status": "created" if apply else "preview", "files": sorted(batch),
            "count": len(batch), "external_tools_installed": False}


def parse_profiles(value: str) -> list[str]:
    result = sorted(set(p.strip() for p in value.split(",") if p.strip()))
    if not result or set(result) - PROFILES:
        raise ValueError("Select one or more profiles: " + ", ".join(sorted(PROFILES)))
    return result


def scaffold(project: str | Path, profiles: list[str], mode: str, apply: bool = False) -> dict[str, Any]:
    root = clean_root(project)
    if not profiles or set(profiles) - PROFILES or mode not in {"new", "existing"}:
        raise ValueError("Invalid profiles or mode")
    template_root = ROOT / "assets/templates"
    state = read_json(template_root / "project.json")
    docs = list(BASE_DOCS)
    if set(profiles) & {"web", "android", "windows"}:
        docs.append("DESIGN.md")
    if set(profiles) & {"backend", "telegram", "android"}:
        docs.append("DATA_API.md")
    if mode == "existing":
        docs.append("AUDIT.md")
    state.update({"mode": mode, "profiles": sorted(set(profiles)), "required_artifacts": ["INDEX.md"] + docs})
    batch = {".engineering/project.json": (json.dumps(state, indent=2) + "\n").encode()}
    for name in docs:
        batch["docs/engineering/" + name] = read_text(template_root / name).encode()
    index = "# Engineering index\n\nStatus: READY\n\nThis is a navigation index, not a completed project audit or approved plan.\n\n"
    index += "\n".join(f"- [{n[:-3].replace('_', ' ').title()}]({n})" for n in docs)
    index += "\n\nRead `.engineering/project.json` from the repository root. Preserve existing canonical specs.\n"
    batch["docs/engineering/INDEX.md"] = index.encode()
    agents = confined(root, "AGENTS.md")
    stub_dest = ".engineering/AGENTS.suggested.md" if agents.exists() else "AGENTS.md"
    batch[stub_dest] = read_text(template_root / "AGENTS.stub.md").encode()
    result = write_batch(root, batch, apply)
    result["note"] = "Planning templates only. Existing AGENTS.md is preserved; merge a suggested pointer manually when present."
    return result


def install(project: str | Path, agent: str, apply: bool = False) -> dict[str, Any]:
    root = clean_root(project)
    if agent not in HOST_PATHS:
        raise ValueError("Unsupported agent")
    prefix = HOST_PATHS[agent] + "/goo-engineering"
    target = confined(root, prefix)
    if target.exists():
        raise ValueError(f"Skill destination already exists: {target}")
    if target.is_relative_to(ROOT):
        raise ValueError("Do not install this skill inside its own source folder")
    batch: dict[str, bytes] = {}
    allowed_dirs = {"agents", "assets", "references", "scripts", "tests"}
    hashes: dict[str, str] = {}
    for path in sorted(ROOT.rglob("*")):
        rel = path.relative_to(ROOT)
        if any(part in {".git", "__pycache__", ".venv"} for part in rel.parts):
            continue
        if is_link(path):
            raise ValueError(f"Refusing linked source file/directory: {rel}")
        if not path.is_file() or (len(rel.parts) > 1 and rel.parts[0] not in allowed_dirs):
            continue
        if path.suffix in {".pyc", ".zip", ".log"}:
            continue
        if path.stat().st_size > 5 * MAX_TEXT_BYTES:
            raise ValueError(f"Source file too large for this installer: {rel}")
        data = path.read_bytes()
        batch[prefix + "/" + rel.as_posix()] = data
        hashes[rel.as_posix()] = hashlib.sha256(data).hexdigest()
    record = {"skill": "goo-engineering", "local_copy_only": True, "host_discovery_verified": False, "sha256": hashes}
    batch[prefix + "/INSTALLATION.json"] = (json.dumps(record, indent=2) + "\n").encode()
    result = write_batch(root, batch, apply)
    result["note"] = "Only this local skill is copied. Verify discovery in the actual host; no third-party tool or SDK was installed."
    return result


def check_plan(project: str | Path) -> dict[str, Any]:
    root = clean_root(project)
    state = read_json(confined(root, ".engineering/project.json"))
    errors: list[str] = []
    if state.get("schema_version") != 1:
        errors.append("Unsupported schema_version")
    if state.get("mode") not in {"new", "existing"}:
        errors.append("mode must be new or existing")
    profiles = state.get("profiles")
    if not isinstance(profiles, list) or not profiles or any(not isinstance(x, str) or x not in PROFILES for x in profiles):
        errors.append("Valid nonempty profiles are required")
    if state.get("profiles_confirmed") is not True:
        errors.append("Profile selection needs confirmation")
    if state.get("risk_level") not in {"low", "standard", "high"}:
        errors.append("Risk level must be assessed")
    if state.get("workflow_provider") not in {"plain", "openspec", "spec-kit", "bmad", "gsd-core", "existing"}:
        errors.append("Choose one workflow provider")
    if state.get("plan_status") != "approved" or not str(state.get("approval_reference") or "").strip():
        errors.append("Approved plan status and a genuine approval reference are required")
    if state.get("blocking_questions") != []:
        errors.append("Resolve or explicitly reclassify declared blocking questions")
    decision = state.get("tools_decision")
    tools = state.get("selected_tools")
    if decision not in {"none-required", "selected"}:
        errors.append("Resolve the tooling decision")
    if not isinstance(tools, list):
        errors.append("selected_tools must be a list")
        tools = []
    if decision == "selected" and not tools:
        errors.append("Selected tool records are missing")
    if decision == "none-required" and tools:
        errors.append("Tool selection conflicts with none-required")
    for i, tool in enumerate(tools):
        if not isinstance(tool, dict):
            errors.append(f"Tool {i} must be an object")
            continue
        for key in ("id", "canonical_source", "immutable_ref", "license_review", "permissions_review", "approval_reference"):
            if not str(tool.get(key) or "").strip():
                errors.append(f"Tool {i} missing {key}")
        ref = str(tool.get("immutable_ref") or "")
        if ref.lower() in {"main", "master", "head", "latest"}:
            errors.append(f"Tool {i} uses a floating reference")
        if not re.fullmatch(r"[a-fA-F0-9]{40,64}", ref) and not tool.get("integrity"):
            errors.append(f"Tool {i} needs a commit hash or integrity digest")
    checks = state.get("required_checks")
    if not isinstance(checks, list) or not checks:
        errors.append("Declare real repository-native required checks and environments")
    else:
        for i, check in enumerate(checks):
            if not isinstance(check, dict) or not check.get("id") or not check.get("environment"):
                errors.append(f"Required check {i} needs id and environment")
                continue
            cmd = check.get("command")
            if not isinstance(cmd, list) or not cmd or not all(isinstance(x, str) and x.strip() for x in cmd):
                errors.append(f"Required check {i} needs an argument-list command")
    docs = state.get("required_artifacts")
    if not isinstance(docs, list) or not docs:
        errors.append("Declare required_artifacts")
        docs = []
    for name in docs:
        try:
            if not isinstance(name, str):
                raise ValueError("Artifact name must be a string")
            path = confined(root, "docs/engineering/" + name)
            body = read_text(path)
            if not re.search(r"^Status:\s*(READY|APPROVED)\s*$", body, re.MULTILINE):
                errors.append(f"Artifact is not marked READY/APPROVED: {name}")
            if "{{" in body or "REPLACE_ME" in body:
                errors.append(f"Artifact has unresolved placeholders: {name}")
        except (OSError, UnicodeError, ValueError) as exc:
            errors.append(f"Cannot validate artifact {name!r}: {exc}")
    return {"status": "blocked" if errors else "structurally-ready", "errors": errors,
            "limitations": "Structural planning validation only. It neither authenticates approval nor runs application tests, verifies architectural quality or certifies a release."}


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description=__doc__)
    sub = parser.add_subparsers(dest="command", required=True)
    d = sub.add_parser("detect", help="Read-only, bounded manifest heuristics")
    d.add_argument("project"); d.add_argument("--max-files", type=int, default=20000)
    s = sub.add_parser("scaffold", help="Preview planning files; --apply to create without overwriting")
    s.add_argument("project"); s.add_argument("--profiles", required=True)
    s.add_argument("--mode", choices=["new", "existing"], required=True)
    s.add_argument("--apply", action="store_true")
    i = sub.add_parser("install", help="Preview project-local copy of this skill only")
    i.add_argument("project"); i.add_argument("--agent", choices=sorted(HOST_PATHS), required=True)
    i.add_argument("--apply", action="store_true")
    c = sub.add_parser("check-plan", help="Check plan structure, not software execution")
    c.add_argument("project")
    args = parser.parse_args(argv)
    try:
        if args.command == "detect": result = detect(args.project, args.max_files)
        elif args.command == "scaffold": result = scaffold(args.project, parse_profiles(args.profiles), args.mode, args.apply)
        elif args.command == "install": result = install(args.project, args.agent, args.apply)
        else: result = check_plan(args.project)
        print(json.dumps(result, indent=2, ensure_ascii=True))
        return 2 if result.get("status") == "blocked" else 0
    except (OSError, UnicodeError, ValueError) as exc:
        print(json.dumps({"status": "error", "message": str(exc)}, ensure_ascii=True), file=sys.stderr)
        return 2


if __name__ == "__main__":
    raise SystemExit(main())
