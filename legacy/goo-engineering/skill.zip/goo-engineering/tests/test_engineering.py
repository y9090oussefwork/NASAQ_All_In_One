"""Local helper tests, not model behavior or platform-build certification."""
import contextlib
import importlib.util
import io
import json
from pathlib import Path
import tempfile
import unittest

spec=importlib.util.spec_from_file_location('engineering',Path(__file__).resolve().parents[1]/'scripts/engineering.py')
eng=importlib.util.module_from_spec(spec)
spec.loader.exec_module(eng)

class EngineeringTests(unittest.TestCase):
    def setUp(self):
        self.tmp=tempfile.TemporaryDirectory(); self.root=Path(self.tmp.name)
    def tearDown(self): self.tmp.cleanup()
    def write(self,rel,data):
        p=self.root/rel; p.parent.mkdir(parents=True,exist_ok=True); p.write_text(data,encoding='utf-8'); return p
    def ready_fixture(self):
        eng.scaffold(self.root,['backend'],'new',True)
        p=self.root/'.engineering/project.json'; s=json.loads(p.read_text())
        s.update(profiles_confirmed=True,risk_level='standard',workflow_provider='plain',plan_status='approved',
                 approval_reference='SYNTHETIC TEST APPROVAL NOT A USER APPROVAL',blocking_questions=[],tools_decision='none-required',
                 required_checks=[{'id':'unit','command':['python','-m','unittest'],'environment':'synthetic-test'}])
        p.write_text(json.dumps(s))
        for n in s['required_artifacts']:
            (self.root/'docs/engineering'/n).write_text('# Synthetic fixture\n\nStatus: READY\n\nTest data, not a real project assessment.\n')
        return p,s
    def test_empty_is_unknown(self):
        r=eng.detect(self.root); self.assertEqual(r['profile_candidates'],{}); self.assertEqual(r['mode_hint'],'unknown')
    def test_detect_multiple_profiles(self):
        self.write('app/src/main/AndroidManifest.xml','<manifest/>')
        self.write('api/package.json','{"dependencies":{"fastify":"x"}}')
        self.write('bot/requirements.txt','aiogram==0\n')
        self.assertEqual(set(eng.detect(self.root)['profile_candidates']),{'android','backend','telegram'})
    def test_plain_javascript_is_not_web(self):
        self.write('index.js','console.log(1)'); self.write('package.json','{"dependencies":{"lodash":"x"}}')
        self.assertNotIn('web',eng.detect(self.root)['profile_candidates'])
    def test_dotnet_web_is_not_windows(self):
        self.write('api.csproj','<Project Sdk="Microsoft.NET.Sdk.Web"/>')
        self.assertEqual(set(eng.detect(self.root)['profile_candidates']),{'backend'})
    def test_windows_ui_marker(self):
        self.write('app.csproj','<Project><UseWPF>true</UseWPF></Project>')
        self.assertIn('windows',eng.detect(self.root)['profile_candidates'])
    def test_react_native_does_not_force_web(self):
        self.write('package.json','{"dependencies":{"react":"x","react-native":"x"}}')
        r=eng.detect(self.root)['profile_candidates']; self.assertIn('android',r); self.assertNotIn('web',r)
    def test_ignored_vendor(self):
        self.write('node_modules/vendor/AndroidManifest.xml','<manifest/>')
        self.assertEqual(eng.detect(self.root)['files_inspected'],0)
    def test_malformed_manifest_reports_warning(self):
        self.write('package.json','{BROKEN'); self.assertTrue(eng.detect(self.root)['warnings'])
    def test_large_manifest_not_read(self):
        self.write('package.json','x'*(eng.MAX_TEXT_BYTES+1)); self.assertTrue(eng.detect(self.root)['warnings'])
    def test_scan_limit_is_explicit(self):
        for n in range(4): self.write(f'{n}.py','pass')
        r=eng.detect(self.root,max_files=2); self.assertEqual(r['files_inspected'],2); self.assertTrue(r['truncated'])
    def test_no_script_execution(self):
        self.write('package.json',json.dumps({'scripts':{'preinstall':'touch SHOULD_NOT_EXIST'},'dependencies':{'next':'x'}}))
        eng.detect(self.root); self.assertFalse((self.root/'SHOULD_NOT_EXIST').exists())
    def test_scaffold_preview_no_writes(self):
        self.assertEqual(eng.scaffold(self.root,['web'],'new')['status'],'preview'); self.assertEqual(list(self.root.iterdir()),[])
    def test_existing_agents_preserved(self):
        self.write('AGENTS.md','KEEP USER INSTRUCTIONS'); eng.scaffold(self.root,['telegram'],'existing',True)
        self.assertEqual((self.root/'AGENTS.md').read_text(),'KEEP USER INSTRUCTIONS')
        self.assertTrue((self.root/'.engineering/AGENTS.suggested.md').exists())
        self.assertTrue((self.root/'docs/engineering/AUDIT.md').exists())
        self.assertFalse((self.root/'docs/engineering/DESIGN.md').exists())
    def test_conflict_preflight_no_partial_write(self):
        self.write('docs/engineering/REQUIREMENTS.md','PRESERVE')
        with self.assertRaises(ValueError): eng.scaffold(self.root,['web'],'new',True)
        self.assertFalse((self.root/'.engineering').exists()); self.assertEqual((self.root/'docs/engineering/REQUIREMENTS.md').read_text(),'PRESERVE')
    def test_draft_plan_is_blocked(self):
        eng.scaffold(self.root,['web'],'new',True); r=eng.check_plan(self.root)
        self.assertEqual(r['status'],'blocked'); self.assertGreater(len(r['errors']),3)
    def test_completed_synthetic_plan_structure(self):
        self.ready_fixture(); self.assertEqual(eng.check_plan(self.root)['status'],'structurally-ready')
    def test_floating_tool_reference_rejected(self):
        p,s=self.ready_fixture(); s['tools_decision']='selected'
        s['selected_tools']=[{'id':'example','canonical_source':'https://example.invalid','immutable_ref':'latest',
                             'license_review':'test','permissions_review':'test','approval_reference':'synthetic'}]
        p.write_text(json.dumps(s)); self.assertTrue(any('floating' in e for e in eng.check_plan(self.root)['errors']))
    def test_artifact_traversal_rejected(self):
        p,s=self.ready_fixture(); s['required_artifacts']=['../../outside.md']; p.write_text(json.dumps(s))
        self.assertEqual(eng.check_plan(self.root)['status'],'blocked')
    def test_confined_rejects_absolute_windows_and_parent(self):
        for bad in ('/etc/passwd','../x','C:\\temp\\x','a/../../x',''):
            with self.subTest(bad=bad):
                with self.assertRaises(ValueError): eng.confined(self.root,bad)
    def test_symlink_destination_rejected(self):
        outside=self.root/'outside'; outside.mkdir()
        try: (self.root/'docs').symlink_to(outside,target_is_directory=True)
        except OSError: self.skipTest('Symlinks unavailable')
        with self.assertRaises(ValueError): eng.scaffold(self.root,['web'],'new',True)
        self.assertEqual(list(outside.iterdir()),[])
    def test_symlink_manifest_not_followed(self):
        self.write('real','{"dependencies":{"next":"x"}}')
        try: (self.root/'package.json').symlink_to(self.root/'real')
        except OSError: self.skipTest('Symlinks unavailable')
        self.assertNotIn('web',eng.detect(self.root)['profile_candidates'])
    def test_install_preview_then_all_host_copies(self):
        for host,subpath in eng.HOST_PATHS.items():
            self.assertEqual(eng.install(self.root,host)['status'],'preview')
            self.assertFalse((self.root/subpath/'goo-engineering').exists())
            eng.install(self.root,host,True); dest=self.root/subpath/'goo-engineering'
            self.assertTrue((dest/'SKILL.md').is_file())
            r=json.loads((dest/'INSTALLATION.json').read_text()); self.assertFalse(r['host_discovery_verified']); self.assertIn('SKILL.md',r['sha256'])
            with self.assertRaises(ValueError): eng.install(self.root,host,True)
    def test_invalid_profile(self):
        for text in ('','unknown','web,not-real'):
            with self.assertRaises(ValueError): eng.parse_profiles(text)
    def test_cli_blocked_exit(self):
        eng.scaffold(self.root,['backend'],'new',True)
        with contextlib.redirect_stdout(io.StringIO()): self.assertEqual(eng.main(['check-plan',str(self.root)]),2)
    def test_cli_missing_root_error(self):
        with contextlib.redirect_stderr(io.StringIO()): self.assertEqual(eng.main(['detect',str(self.root/'missing')]),2)

if __name__=='__main__': unittest.main()
