# Changelog

## 0.2.0 — instructional preview — 2026-10-09

Added capability-based provider selection, Arabic-first ownership/conflict policy, a context-sensitive source catalog, read-only selection-manifest validation, example manifests, tests and a complete build-specification revision 1.1. Preserved earlier lifecycle, security, performance, documentation and approval requirements.

This is the first packaged Nasaq instructional preview in this delivery. It is not an in-place update of a verified installed Nasaq runtime. The older Goo Engineering archive and original build-spec file are preserved separately. All external integrations remain untested here.
