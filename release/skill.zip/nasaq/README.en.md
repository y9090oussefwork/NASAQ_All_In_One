# Nasaq — instructional preview 0.2.0

Nasaq provides an Arabic-first, English-selectable conversational interface for software-engineering work. One primary owner is selected for each capability, component and phase. Reviewers, executable tools and official references have separate roles.

## What this distribution actually contains
It includes an original [SKILL.md](SKILL.md), lifecycle references, a source-backed [provider catalog](references/provider-catalog-ar.md), capability and provider JSON registries, example selection manifests, a read-only static validator and its tests. The detailed engineering references are currently written in Arabic; multilingual host agents can respond in English when requested. The validator has explicit Arabic/English message catalogs. Host-model language behavior has not been benchmarked.

It does not implement all of the runtime, installers, provider adapters or host integrations described in the full build specification. All external providers are catalog candidates, not installed integrations. No upstream skill source or font files are vendored.

## Usage
Ask a file-capable coding agent to read SKILL.md and apply Nasaq to the current task. This is manual instruction loading, not proof of native installation. Use the host's documented skill installation method separately and preserve existing project/global instructions.

Examples: `nasaq start`, `nasaq tools for design`, `nasaq recommend backend guidance`, `nasaq review`, `nasaq language en`. Users should not need to learn the commands of each optional provider.

## Provider selection contract
Choose the application's technology from requirements and constraints first. Then choose version-matched expertise. Present at most three comparable candidates per decision, with reasons, costs, privacy and evidence. Retain a suitable existing toolchain. Do not activate multiple aesthetic designers or specification engines for the same responsibility. Technical frontend guidance can complement a designer only under explicit scope contracts.

Global hooks and already-loaded instructions cannot be disabled merely by changing a manifest. Detect and resolve them with host-supported isolation and user approval. Preserve approved API/schema/design contracts. Reviewers do not rewrite product code or acceptance criteria. Skip, waived or blocked tests are not passed tests.

## Local validator
Requires Python 3.11+ and the standard library. From this directory:

```text
python scripts/check_selection.py assets/examples/web-selection.draft.json --lang en
python scripts/check_selection.py assets/examples/conflicting-design.draft.json --lang en
python -m unittest discover -s tests -v
```

The validator checks declared ownership, scopes, technology tags, write overlaps within a phase and explicit activation conflicts. `--ready` additionally checks declared source metadata, adapter status and an approval digest. These fields are not independently authenticated. The checker never installs, downloads or runs providers, and is not a semantic instruction-conflict detector, access-control sandbox or assurance of application quality.

## Continue building Nasaq
Read the full [Arabic build specification 1.1](assets/NASAQ_BUILD_SPEC_AR_v1_1.md). Compare it with any existing implementation; do not overwrite or rebuild blindly. Preserve the original lifecycle, Arabic/English behavior, explicit approvals and evidence requirements. Implement and test provider adapters gradually. Do not publish, install globally or use paid services without authorization.

See [VALIDATION.md](VALIDATION.md) for actual tests and limitations. The proposed MIT license covers the original Nasaq material, not referenced third-party projects. Verify ownership details before a public release.
